package ustensiles;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbInfo {
	private static String username = "root";
	private static String password = "1234";
	private static String host = "jdbc:mysql://localhost:3306/testuste";
	
	public static Connection connDB() throws SQLException {
		return DriverManager.getConnection(host, username, password);
	}
}
